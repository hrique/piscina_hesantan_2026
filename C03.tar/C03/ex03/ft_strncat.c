//#include <stdio.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	while (dest[i] != '\0')
	{
		i++;
	}
	while (j < nb && nb != 0)
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';
	return (dest);
}

/*int	main(void)
{
	char	text1[20] = "teste";
	char	text2[] = "zzzzz";
	unsigned int	n;

	n = 4;
	ft_strncat(text1, text2, n);
	printf("%s", text1);
	return (0);
}*/
